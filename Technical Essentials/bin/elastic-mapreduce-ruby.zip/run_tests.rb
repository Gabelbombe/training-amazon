#
# Copyright 2011-2013 Amazon.com, Inc. or its affiliates.  All Rights Reserved.

$LOAD_PATH << File.dirname(__FILE__)

require 'tests/commands_test'


